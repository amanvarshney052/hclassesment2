package com.example.hclassesment2.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class OrderItem {
    @Id
    private Long orderItemId;

    private CustomerOrder customerOrder;

    private Product product;

    private Integer quantity;

    private Double price;
}
