package com.example.hclassesment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Customer {

    @Id
    private Long customerId;

    private String customerName;

    private String password;

    private String mobile;

    private String city;



}
