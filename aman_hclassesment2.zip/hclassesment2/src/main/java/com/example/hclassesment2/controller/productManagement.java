package com.example.hclassesment2.controller;


import com.example.hclassesment2.entity.Customer;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class productManagement {



    @PostMapping
    public Customer registerCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = customerService.registerCustomer(customer);
        return createdCustomer;
    }


}
