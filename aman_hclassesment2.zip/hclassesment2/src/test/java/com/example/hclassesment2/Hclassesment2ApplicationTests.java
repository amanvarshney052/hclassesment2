package com.example.hclassesment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hclassesment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
