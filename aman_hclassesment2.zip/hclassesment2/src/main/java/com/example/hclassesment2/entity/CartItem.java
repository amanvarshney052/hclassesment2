package com.example.hclassesment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class CartItem {
    @Id
    private Long cartItemId;

    private Cart cart;

    private Product product;

    private Integer quantity;

    private Double price;
}
