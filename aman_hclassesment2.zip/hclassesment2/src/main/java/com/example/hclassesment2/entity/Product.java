package com.example.hclassesment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
    @Id
    private Long productId;

    private String productName;

    private String description;

    private Double price ;

    private Integer quantity;

    private String category;
}
