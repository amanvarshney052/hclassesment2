package com.example.hclassesment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hclassesment2Application {

	public static void main(String[] args) {

		SpringApplication.run(Hclassesment2Application.class, args);
	}

}
