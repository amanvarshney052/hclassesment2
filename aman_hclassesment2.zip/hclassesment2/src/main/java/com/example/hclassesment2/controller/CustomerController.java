package com.example.hclassesment2.controller;

import com.example.hclassesment2.entity.Customer;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.service.CustomerService;


@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final com.example.service.CustomerService customerService;

    public CustomerController( CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping
    public Customer registerCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = customerService.registerCustomer(customer);
        return createdCustomer;
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        List<Customer> customers = customerService.getAllCustomers();
        return customers;
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        return customer;
    }

    @PutMapping("/{id}")
    public Customer updateCustomer(@PathVariable Long id, @RequestBody Customer customerDetails) {
        Customer updatedCustomer = customerService.updateCustomer(id, customerDetails);
        return updatedCustomer;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
