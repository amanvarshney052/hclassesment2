package com.example.hclassesment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.time.LocalDate;
@Entity
public class Cart {
    @Id
    private Long cartId;

    private Customer customer;

    private LocalDate createdDate;
}
